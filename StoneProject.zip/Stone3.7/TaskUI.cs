using System;

public class TaskUI
{
    public string ConsoleOutput { get; set; }

    public void DisplayTasks(List<Task> taskList)
    {
        foreach (var task in taskList)
        {
            Console.WriteLine($"Task: {task.TaskName} | Due Date: {task.DueDate} | Priority: {task.Priority} | Completed: {task.IsCompleted}");
        }
    }

    public void DisplayMessage(string message)
    {
        Console.WriteLine(message);
    }
}