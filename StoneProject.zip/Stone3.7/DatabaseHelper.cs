using System;
using System.Data.SQLite;

public static class DatabaseHelper
{
private const string ConnectionString = "Data Source=TaskMasterDatabase.db;Version=3;";

public static void InsertTask(Task task)
{
using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
{
connection.Open();

string insertQuery = "INSERT INTO TaskTable (TaskName, DueDate, Priority, IsCompleted) " +
"VALUES (@TaskName, @DueDate, @Priority, @IsCompleted)";

using (SQLiteCommand command = new SQLiteCommand(insertQuery, connection))
{
command.Parameters.AddWithValue("@TaskName", task.TaskName);
command.Parameters.AddWithValue("@DueDate", task.DueDate.ToString("yyyy-MM-dd HH:mm:ss"));
command.Parameters.AddWithValue("@Priority", (int)task.Priority);
command.Parameters.AddWithValue("@IsCompleted", task.IsCompleted);

command.ExecuteNonQuery();
}

connection.Close();
}
}

public static void UpdateTask(Task task)
{
using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
{
connection.Open();

string updateQuery = "UPDATE TaskTable SET IsCompleted = @IsCompleted WHERE TaskID = @TaskID";

using (SQLiteCommand command = new SQLiteCommand(updateQuery, connection))
{
command.Parameters.AddWithValue("@IsCompleted", task.IsCompleted);
command.Parameters.AddWithValue("@TaskID", task.TaskID);

command.ExecuteNonQuery();
}

connection.Close();
}
}
}