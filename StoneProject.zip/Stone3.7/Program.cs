﻿using System;

class Program
{
static void Main()
{
// Create the database and TaskTable
DatabaseManager.CreateDatabase();

TaskManager taskManager = new TaskManager();
TaskUI taskUI = new TaskUI();

// Create sample tasks
Task task1 = new Task { TaskName = "Complete Project", DueDate = DateTime.Now.AddDays(7), Priority = Priority.High };
Task task2 = new Task { TaskName = "Prepare Presentation", DueDate = DateTime.Now.AddDays(3), Priority = Priority.Medium };

// Add tasks to the task manager
taskManager.AddTask(task1);
taskManager.AddTask(task2);

// Add tasks to the database
DatabaseHelper.InsertTask(task1);
DatabaseHelper.InsertTask(task2);

// Display tasks
taskUI.DisplayTasks(taskManager.TaskList);

// Mark task as completed
task1.MarkAsCompleted();

// Update task in the database
DatabaseHelper.UpdateTask(task1);

// Display updated tasks
taskUI.DisplayTasks(taskManager.TaskList);

Console.ReadLine(); // To keep the console window open
}
}