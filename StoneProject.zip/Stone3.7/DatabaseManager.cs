using System;
using System.Data.SQLite;

public class DatabaseManager
{
private const string ConnectionString = "Data Source=TaskMasterDatabase.db;Version=3;";

public static void CreateDatabase()
{
using (SQLiteConnection connection = new SQLiteConnection(ConnectionString))
{
connection.Open();

string createTableQuery = "CREATE TABLE IF NOT EXISTS TaskTable (" +
"TaskID INTEGER PRIMARY KEY AUTOINCREMENT, " +
"TaskName TEXT NOT NULL, " +
"DueDate DATETIME NOT NULL, " +
"Priority INTEGER NOT NULL, " +
"IsCompleted BOOLEAN NOT NULL)";

using (SQLiteCommand command = new SQLiteCommand(createTableQuery, connection))
{
command.ExecuteNonQuery();
}

connection.Close();
}
}
}