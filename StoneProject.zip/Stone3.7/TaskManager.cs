using System;
using System.Collections.Generic;

public class TaskManager
{
    public List<Task> TaskList { get; set; }

    public TaskManager()
    {
        TaskList = new List<Task>();
    }

    public void AddTask(Task task)
    {
        TaskList.Add(task);
    }

    public void RemoveTask(Task task)
    {
        TaskList.Remove(task);
    }

    public List<Task> GetTasksByPriority(Priority priority)
    {
        return TaskList.FindAll(task => task.Priority == priority);
    }
}