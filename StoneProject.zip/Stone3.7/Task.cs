using System;

public enum Priority
{
    Low,
    Medium,
    High
}

public class Task
{
    public string TaskName { get; set; }
    public DateTime DueDate { get; set; }
    public Priority Priority { get; set; }
    public bool IsCompleted { get; set; }

    public void MarkAsCompleted()
    {
        IsCompleted = true;
    }

    public void UpdateDueDate(DateTime newDueDate)
    {
        DueDate = newDueDate;
    }
}